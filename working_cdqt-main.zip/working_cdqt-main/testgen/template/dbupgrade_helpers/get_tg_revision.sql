SELECT revision
  FROM {SCHEMA_NAME}.tg_revision;
