# ruff: noqa: F401

from testgen.ui.views.table_groups.forms import TableGroupForm
from testgen.ui.views.table_groups.page import TableGroupsPage
