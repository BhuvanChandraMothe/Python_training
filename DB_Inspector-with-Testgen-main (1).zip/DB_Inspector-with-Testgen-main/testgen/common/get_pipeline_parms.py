from testgen.common.database.database_service import RetrieveDBResultsToDictList
from testgen.common.read_file import read_template_sql_file


# def RetrieveProfilingParms(strTableGroupsID):
#     strSQL = read_template_sql_file("parms_profiling.sql", "parms")
#     # Replace Parameters
#     strSQL = strSQL.replace("{TABLE_GROUPS_ID}", strTableGroupsID)

#     # Execute Query
#     lstParms = RetrieveDBResultsToDictList("DKTG", strSQL)

#     if lstParms is None:
#         raise ValueError("Project Connection Parameters not found")

#     required_params = (
#         "project_code",
#         "connection_id",
#         "sql_flavor",
#         #"project_user",
#         "profile_use_sampling",
#         "profile_sample_percent",
#         "profile_sample_min_count",
#         "table_group_schema",
        
#     )

#     if missing := [param for param in required_params if not lstParms[0][param]]:
#         raise ValueError(f"Project Connection parameters are missing: {', '.join(missing)}.")

#     return lstParms[0]



def RetrieveProfilingParms(strTableGroupsID):
    """
    Retrieves profiling parameters for a given table group ID from the configuration database.
    Dynamically adjusts required parameters based on the SQL flavor.

    Args:
        strTableGroupsID (str): The ID of the table group to retrieve parameters for.

    Returns:
        dict: A dictionary containing the retrieved connection and profiling parameters.

    Raises:
        ValueError: If connection parameters are not found or if required parameters
                    for the specific SQL flavor are missing.
    """
    strSQL = read_template_sql_file("parms_profiling.sql", "parms")
    strSQL = strSQL.replace("{TABLE_GROUPS_ID}", strTableGroupsID)

    lstParms = RetrieveDBResultsToDictList("DKTG", strSQL)

    if lstParms is None or not lstParms: # Ensure list is not empty
        raise ValueError("Project Connection Parameters not found or empty.")

    # Get the SQL flavor from the retrieved parameters
    # Default to an empty string and convert to lowercase for robust comparison
    sql_flavor = lstParms[0].get("sql_flavor", "").lower()

    # Define base required parameters common to all flavors
    # These are fundamental for any profiling run
    base_required_params = [
        "project_code",
        "connection_id",
        "sql_flavor",
        "profile_use_sampling",
        "profile_sample_percent",
        "profile_sample_min_count",
        "table_group_schema", # For BigQuery, this is the Dataset ID (your project_db)
    ]

    # Initialize a list for flavor-specific required parameters
    flavor_specific_required_params = []

    # Add required parameters based on SQL flavor
    if sql_flavor in ["databricks", "snowflake", "postgres"]:
        # For traditional relational databases or Databricks with standard auth
        flavor_specific_required_params.extend([
            "project_user",
            "project_host",
            "project_port",
            # project_pw_encrypted is typically not validated for 'truthiness' here
            # as it's binary/encrypted and might legitimately be an empty string if not set,
            # but rather validated when the connection is attempted.
        ])
        if sql_flavor == "databricks":
            # Databricks specific: http_path
            flavor_specific_required_params.append("http_path")
    elif sql_flavor == "bigquery":
        # For BigQuery, specific auth methods dictate what's required
        # Check if connect_by_key is true and private_key exists
        if lstParms[0].get("connect_by_key") is True:
            # private_key should be non-empty (assuming "binary data" counts as non-empty)
            flavor_specific_required_params.append("private_key")
        # Check if connect_by_url is true and url exists
        elif lstParms[0].get("connect_by_url") is True:
            # url should be non-empty
            flavor_specific_required_params.append("url")
        # If neither connect_by_key nor connect_by_url is True, it might imply
        # Application Default Credentials (ADC) or environment variables,
        # in which case no explicit key/URL is required here.
    else:
        # Handle unknown SQL flavors - perhaps log a warning or raise an error
        print(f"WARNING: Unknown SQL flavor '{sql_flavor}'. Proceeding with base requirements.")

    # Combine all required parameters for the current flavor
    all_required_params = base_required_params + flavor_specific_required_params

    # Check for missing parameters.
    # A parameter is 'missing' if it's in `all_required_params`
    # AND its value in `lstParms[0]` is either None, or an empty string, or False
    # (unless it's a boolean flag where False is a valid setting).
    missing_params = []
    for param in all_required_params:
        param_value = lstParms[0].get(param)

        # Special handling for boolean flags where False is a valid configuration
        if param in ["profile_use_sampling", "connect_by_url", "connect_by_key"]:
            # If the value is explicitly False or True, it's valid.
            # It's only 'missing' if it's None or not provided at all.
            if param_value is None:
                missing_params.append(param)
        else:
            # For non-boolean parameters, check for None or empty string
            if not param_value: # Catches None, "", 0 (if numeric), False (if boolean, but handled above)
                missing_params.append(param)


    if missing_params:
        raise ValueError(f"Project Connection parameters are missing: {', '.join(missing_params)}.")

    return lstParms[0]


def RetrieveTestGenParms(strTableGroupsID, strTestSuite):
    strSQL = read_template_sql_file("parms_test_gen.sql", "parms")
    # Replace Parameters
    strSQL = strSQL.replace("{TABLE_GROUPS_ID}", strTableGroupsID)
    strSQL = strSQL.replace("{TEST_SUITE}", strTestSuite)

    # Execute Query
    lstParms = RetrieveDBResultsToDictList("DKTG", strSQL)
    if len(lstParms) == 0:
        raise ValueError("SQL retrieved 0 records")
    return lstParms[0]


def RetrieveTestExecParms(strProjectCode, strTestSuite):
    strSQL = read_template_sql_file("parms_test_execution.sql", "parms")
    # Replace Parameters
    strSQL = strSQL.replace("{PROJECT_CODE}", strProjectCode)
    strSQL = strSQL.replace("{TEST_SUITE}", strTestSuite)

    # Execute Query
    lstParms = RetrieveDBResultsToDictList("DKTG", strSQL)
    if len(lstParms) == 0:
        raise ValueError("Test Execution parameters could not be retrieved")
    elif len(lstParms) > 1:
        raise ValueError("Test Execution parameters returned too many records")

    return lstParms[0]
