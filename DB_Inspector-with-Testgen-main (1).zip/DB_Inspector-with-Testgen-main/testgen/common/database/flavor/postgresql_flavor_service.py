from testgen.common.database.flavor.redshift_flavor_service import RedshiftFlavorService
import logging

class PostgresqlFlavorService(RedshiftFlavorService):
    pass
