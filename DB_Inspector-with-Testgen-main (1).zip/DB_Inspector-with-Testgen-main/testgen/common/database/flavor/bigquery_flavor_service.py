from google.cloud import bigquery
from google.oauth2 import service_account
import json

from testgen.common.database.flavor.flavor_service import FlavorService
from testgen.common.encrypt import DecryptText
import logging

LOG = logging.getLogger(__name__) 

class BigqueryFlavorService(FlavorService):
    """
    Flavor service for Google BigQuery.
    Handles BigQuery-specific connection parameters and client initialization.
    """

    project_id = None
    dataset_id = None
    service_account_info = None # To store parsed JSON key content

    def init(self, connection_params: dict):
        """
        Initializes BigQuery specific connection parameters.
        """
        super().init(connection_params)

        # BigQuery uses project_id as its primary scoping for billing and resources
        self.project_id = connection_params.get("project_id", "vibrant-tiger-458903-k1") # Fallback to dbname if project_id isn't explicit
        self.dataset_id = connection_params.get("project_db") # Use dbschema for dataset_id
        decrypted_privatekey = self.private_key
        
        
        print(f"DEBUG: The project id: {self.project_id}") # Print type
        print(f"DEBUG: Type of self.private_key after super().init: {type(self.private_key)}") # Print type
        print(f"DEBUG: Value of raw self.private_key: {self.private_key[:100]}...") 
        print(f"DEBUG: Value of decrypted private key: {decrypted_privatekey}...") 
        print(f"Debug: Value of self.connect_by_key: {self.connect_by_key}") # Print type
        
        

        if self.private_key:
            try:
                self.service_account_info = json.loads(decrypted_privatekey)
                
                LOG.debug(f"Type of self.service_account_info (after json.loads): {type(self.service_account_info)}")
                # self.service_account_info is now a dict. Log it appropriately by converting to string.
                LOG.debug(f"Value of parsed service_account_info (truncated): {str(self.service_account_info)[:200]}...")
            
            except json.JSONDecodeError as e:
                error_message = (
                    f"Invalid JSON format for BigQuery private_key content. Error: {e}. "
                    f"Decrypted content starts with: '{decrypted_privatekey[:50]}...'"
                )
                LOG.error(error_message) # Log the full error
                raise ValueError(error_message) # Raise a simple ValueError with a string message
            
            except Exception as e:
                # Catch any other unexpected errors during parsing
                error_message = f"Unexpected error when parsing private_key content: {type(e).__name__}: {e}"
                LOG.exception(error_message) # Log with traceback
                raise RuntimeError(error_message) # Raise a simple RuntimeError with a string message

        elif self.connect_by_key and not decrypted_privatekey:
            raise ValueError("connect_by_key is True but decrypted private_key content is empty.")
        elif not self.connect_by_key:
            LOG.info("Connecting to BigQuery without service account key (will use ADC).")

    def get_connection_string_head(self, strPW):
        """
        BigQuery doesn't use a traditional connection string head.
        This method is less relevant for BigQuery direct client.
        We return a conceptual string for logging/identification if needed.
        """
        # For BigQuery, a "connection string" is more about the project and authentication method
        if self.connect_by_key:
            print(f"Creating engine with connection string: {bigquery://{self.project_id}}")
            return f"bigquery://{self.project_id}"
            
        elif self.username: # Assuming user-based auth if not by key (less common for programmatic)
             return f"bigquery_user://{self.username}@{self.project_id}"
        else:
             return f"bigquery://{self.project_id}"


    def get_connection_string_from_fields(self, strPW, is_password_overwritten: bool = False):
        """
        BigQuery doesn't use a standard connection string for SQLAlchemy in the same
        way as traditional databases. Instead, SQLAlchemy uses the `bigquery://project_id/dataset_id`
        format, and authentication is handled via `connect_args`.

        We will construct a SQLAlchemy connection URL for BigQuery.
        """
        # The project_id is crucial for BigQuery.
        if not self.project_id:
            raise ValueError("BigQuery connection requires a 'project_id'.")
        if self.dataset_id:
            strConnect = f"bigquery://{self.project_id}/{self.dataset_id}"
            print(f"Creating engine with connection string: {strConnect}")

        else:
            strConnect = f"bigquery://{self.project_id}"

        return strConnect

    def get_connect_args(self, is_password_overwritten: bool = False):
            """
            Returns a dictionary of connection arguments for the SQLAlchemy engine.
            For BigQuery, this is where we pass the service account credentials dictionary.
            """
            connect_args = super().get_connect_args(is_password_overwritten)
            LOG.debug(f"debug self.service_account_info: {self.service_account_info}")
            LOG.debug(f"debug self.connect_by_key: {self.connect_by_key}")

            if self.connect_by_key and self.service_account_info:
                # SQLAlchemy BigQuery dialect's 'credentials_info' argument expects
                # the raw service account key DICTIONARY, not a Credentials object.
                # We already have the dictionary in self.service_account_info.
                connect_args["credentials_info"] = self.service_account_info # <-- CHANGE HERE

                # If you need to specify scopes, the sqlalchemy-bigquery package might have
                # a separate `scopes` argument in connect_args, or it infers
                # from the credentials. Generally, `credentials_info` is just the dict.
                # If your dialect specifically needs scopes here, you would add:
                # connect_args["scopes"] = ["https://www.googleapis.com/auth/bigquery"]
                LOG.info("BigQuery credentials dictionary added to connect_args['credentials_info'].")

            else:
                # Fallback to default application credentials (e.g., if running on a GCP VM)
                LOG.info("Attempting BigQuery connection using Application Default Credentials (ADC).")
                try:
                    from google.auth import default
                    credentials, project = default()
                    # When using ADC, the 'credentials' key is used for the Credentials object
                    # returned by google.auth.default()
                    connect_args["credentials"] = credentials # <-- THIS IS CORRECT FOR ADC
                    # If project_id wasn't explicitly set, it might be inferred here
                    if not self.project_id:
                        self.project_id = project
                    LOG.info(f"ADC found. Inferred project_id: {self.project_id}")
                except Exception as e:
                    error_message = (
                        f"BigQuery connection failed: No valid private_key provided AND "
                        f"Application Default Credentials could not be found. Error: {type(e).__name__}: {e}. "
                        f"See https://cloud.google.com/docs/authentication/external/set-up-adc for more."
                    )
                    LOG.error(error_message)
                    raise RuntimeError(error_message)

            return connect_args
    
    def get_pre_connection_queries(self):
        """
        BigQuery doesn't have session-level setup queries like some traditional databases.
        """
        return []

    def get_concat_operator(self):
        """
        BigQuery uses `||` for string concatenation, or `CONCAT()` function.
        `||` is generally compatible with standard SQL.
        """
        return "||"



# from urllib.parse import quote_plus
# from testgen.common.database.flavor.flavor_service import FlavorService
# from google.cloud import bigquery
# from google.oauth2 import service_account
# import json

# from testgen.common.database.flavor.flavor_service import FlavorService
# from testgen.common.encrypt import DecryptText
# import logging

# LOG = logging.getLogger(__name__) 


# class BigqueryFlavorService(FlavorService):

#     def get_connection_string_head(self, strPW):
#         # Password not typically used; authentication via service account file
#         return f"bigquery://"

#     def get_connection_string_from_fields(self, strPW, is_password_overwritten: bool = False):
#         # Construct basic BigQuery connection string (no password needed)
#         # Expected fields: project_id, dataset, optional credentials_json
#         decryptedkey =  DecryptText(self.private_key)
#         self.private_key = json.loads(decryptedkey)
#         project_id = self.project_code # reuse `dbname` as project_id
#         dataset = self.dbschema   # reuse `dbschema` as dataset

#         strConnect = f"bigquery://{project_id}/{dataset}"
#         return strConnect

#     def get_connect_args(self, is_password_overwritten: bool = False):
#         connect_args = super().get_connect_args(is_password_overwritten)

#         # Use credentials from JSON if provided
#         if self.private_key:
#             decryptedkey =  DecryptText(self.private_key)
#             self.private_key = json.loads(decryptedkey)
#             # `private_key` here should be a JSON string (service account key)
#             scopes = ["https://www.googleapis.com/auth/bigquery"] 
#             try:
#                 credentials = service_account.Credentials.from_service_account_info(
#                     self.private_key,
#                     scopes=scopes # Pass the required scopes
#                 )
#                 connect_args["credentials"] = credentials
#                 LOG.info("BigQuery credentials created from service account info with specified scopes.")
                
#             except Exception as e:
#                 raise Exception(f"Failed to write BigQuery service account credentials: {str(e)}")

#         return connect_args

#     def get_pre_connection_queries(self):
#         return []
