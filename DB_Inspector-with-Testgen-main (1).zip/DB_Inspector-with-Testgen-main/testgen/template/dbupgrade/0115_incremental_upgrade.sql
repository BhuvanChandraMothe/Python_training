SET SEARCH_PATH TO {SCHEMA_NAME};

ALTER TABLE connections DROP COLUMN project_qc_schema;
