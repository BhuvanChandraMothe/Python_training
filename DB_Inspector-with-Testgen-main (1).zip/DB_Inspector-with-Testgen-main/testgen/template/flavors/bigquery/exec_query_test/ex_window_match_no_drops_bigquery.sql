SELECT
    '{TEST_TYPE}' AS test_type,
    '{TEST_DEFINITION_ID}' AS test_definition_id,
    '{TEST_SUITE_ID}' AS test_suite_id,
    '{TEST_RUN_ID}' AS test_run_id,
    '{RUN_DATE}' AS test_time,
    '{START_TIME}' AS starttime,
    CURRENT_TIMESTAMP() AS endtime,
    '{DATA_SCHEMA}' AS schema_name, -- In BigQuery, SCHEMA_NAME is the Dataset ID
    '{TABLE_NAME}' AS table_name,
    '{COLUMN_NAME_NO_QUOTES}' AS column_names,
    '{SKIP_ERRORS}' AS threshold_value,
    CAST({SKIP_ERRORS} AS INT64) AS skip_errors, -- Ensure SKIP_ERRORS is cast to INT64 for BigQuery
    '{INPUT_PARAMETERS}' AS input_parameters,
    CASE WHEN COUNT(*) > CAST({SKIP_ERRORS} AS INT66) THEN 0 ELSE 1 END AS result_code,
    CASE
        WHEN COUNT(*) > 0 THEN
            CONCAT(
                CAST(COUNT(*) AS STRING),
                ' error(s) identified, ',
                CASE
                    WHEN COUNT(*) > CAST({SKIP_ERRORS} AS INT64) THEN 'exceeding limit of '
                    ELSE 'within limit of '
                END,
                CAST({SKIP_ERRORS} AS STRING), -- Cast for string concatenation
                '.'
            )
        ELSE 'No errors found.'
    END AS result_message,
    COUNT(*) AS result_measure,
    '{SUBSET_DISPLAY}' AS subset_condition,
    NULL AS result_query
FROM (
    SELECT DISTINCT {COLUMN_NAME_NO_QUOTES}
    FROM `{PROJECT_ID}.{DATA_SCHEMA}.{TABLE_NAME}` -- Use full path for table
    WHERE {SUBSET_CONDITION}
        AND {WINDOW_DATE_COLUMN} >= DATE_SUB(
                                        (SELECT MAX({WINDOW_DATE_COLUMN}) FROM `{PROJECT_ID}.{DATA_SCHEMA}.{TABLE_NAME}` WHERE {SUBSET_CONDITION}),
                                        INTERVAL 2 * {WINDOW_DAYS} DAY
                                    )
        AND {WINDOW_DATE_COLUMN} < DATE_SUB(
                                        (SELECT MAX({WINDOW_DATE_COLUMN}) FROM `{PROJECT_ID}.{DATA_SCHEMA}.{TABLE_NAME}` WHERE {SUBSET_CONDITION}),
                                        INTERVAL {WINDOW_DAYS} DAY
                                    )
    EXCEPT DISTINCT
    SELECT DISTINCT {COLUMN_NAME_NO_QUOTES}
    FROM `{PROJECT_ID}.{DATA_SCHEMA}.{TABLE_NAME}` -- Use full path for table
    WHERE {SUBSET_CONDITION}
        AND {WINDOW_DATE_COLUMN} >= DATE_SUB(
                                        (SELECT MAX({WINDOW_DATE_COLUMN}) FROM `{PROJECT_ID}.{DATA_SCHEMA}.{TABLE_NAME}` WHERE {SUBSET_CONDITION}),
                                        INTERVAL {WINDOW_DAYS} DAY
                                    )
) test;