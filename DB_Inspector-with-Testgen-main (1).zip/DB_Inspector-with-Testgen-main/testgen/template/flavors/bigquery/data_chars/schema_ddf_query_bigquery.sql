SELECT
    'vibrant-tiger-458903-k1' AS project_id , -- This will be substituted with your DB's "project_code" (GCP Project ID)
    CURRENT_TIMESTAMP() AS refresh_timestamp,
    c.table_schema AS table_schema, -- In BigQuery, table_schema is the dataset_id, which aligns with your DB's "project_db"
    c.table_name,
    c.column_name,
    CASE
        WHEN lower(c.data_type) = 'string' THEN 'varchar'
        WHEN lower(c.data_type) = 'int64' THEN 'bigint'
        WHEN lower(c.data_type) = 'float64' THEN 'float'
        WHEN lower(c.data_type) = 'numeric' THEN 'numeric'
        WHEN lower(c.data_type) = 'bignumeric' THEN 'numeric' -- Treat BIGNUMERIC similarly to NUMERIC
        WHEN lower(c.data_type) = 'boolean' THEN 'boolean'
        WHEN lower(c.data_type) = 'timestamp' THEN 'timestamp'
        WHEN lower(c.data_type) = 'date' THEN 'date'
        WHEN lower(c.data_type) = 'datetime' THEN 'datetime'
        WHEN lower(c.data_type) = 'time' THEN 'time'
        WHEN lower(c.data_type) = 'bytes' THEN 'bytea' -- Common representation for binary data
        WHEN lower(c.data_type) = 'geography' THEN 'text' -- Represent GEOGRAPHY as text for generic profiling
        WHEN lower(c.data_type) LIKE 'array%' THEN 'array' -- Indicate array type
        WHEN lower(c.data_type) LIKE 'struct%' THEN 'struct' -- Indicate struct type
        ELSE lower(c.data_type) -- Fallback for any unhandled types
    END AS data_type,
    -- BigQuery STRING type does not have a fixed character_maximum_length in information_schema.columns
    -- Returning NULL as there isn't a direct equivalent of max length for STRING types.
    NULL AS character_maximum_length,
    c.ordinal_position,
    CASE
        WHEN lower(c.data_type) = 'string' THEN 'A'
        WHEN lower(c.data_type) = 'boolean' THEN 'B'
        WHEN lower(c.data_type) IN ('date', 'timestamp', 'datetime') THEN 'D'
        WHEN lower(c.data_type) IN ('int64', 'float64', 'numeric', 'bignumeric') THEN 'N'
        WHEN lower(c.data_type) = 'time' THEN 'T'
        ELSE 'X' -- For ARRAY, STRUCT, GEOGRAPHY, BYTES, or any other unhandled types
    END AS general_type,
    CASE
        WHEN lower(c.data_type) IN ('numeric', 'bignumeric', 'float64') THEN 1 -- Corrected line
        ELSE 0
    END AS is_decimal
FROM `vibrant-tiger-458903-k1.dataquality`.INFORMATION_SCHEMA.COLUMNS AS c
WHERE c.table_schema = 'dataquality'  AND c.table_name IN ('land_registry') AND ((c.table_name LIKE '%%')) AND NOT ((c.table_name LIKE 'tmp%%'))
ORDER BY c.table_schema, c.table_name, c.ordinal_position;