-- Get Freqs for selected columns and Distinct Value Hash
WITH ranked_vals AS (
    SELECT
        CAST(`{COL_NAME}` AS STRING) AS column_value, -- Ensure column is string for consistent handling
        COUNT(*) AS ct,
        ROW_NUMBER() OVER (ORDER BY COUNT(*) DESC, CAST(`{COL_NAME}` AS STRING)) AS rn -- Order by value for tie-breaking
    FROM
        `{PROJECT_ID}.{DATA_SCHEMA}.{DATA_TABLE}`
    WHERE
        CAST(`{COL_NAME}` AS STRING) > '' -- Filter out NULLs and empty strings
    GROUP BY
        CAST(`{COL_NAME}` AS STRING)
),
consol_vals AS (
    SELECT
        COALESCE(
            CASE WHEN rn <= 10 THEN CONCAT('| ', column_value, ' | ', CAST(ct AS STRING)) ELSE NULL END,
            CONCAT(
                '| Other Values (',
                CAST(COUNT(DISTINCT column_value) AS STRING), -- COUNT(DISTINCT) for 'Other Values'
                ') | ',
                CAST(SUM(ct) AS STRING)
            )
        ) AS val,
        MIN(rn) AS min_rn -- Keep min_rn to ensure 'Other Values' is last
    FROM
        ranked_vals
    GROUP BY
        CASE WHEN rn <= 10 THEN CONCAT('| ', column_value, ' | ', CAST(ct AS STRING)) ELSE NULL END
)
SELECT
    '{PROJECT_CODE}' AS project_code,
    '{DATA_SCHEMA}' AS schema_name,
    '{RUN_DATE}' AS run_date,
    '{DATA_TABLE}' AS table_name,
    '{COL_NAME_NO_QUOTES}' AS column_name, -- Use NO_QUOTES for the column_name output field
    STRING_AGG(val, '\n' ORDER BY min_rn) AS top_freq_values, -- Use '\n' directly for newline
    -- Calculate distinct_value_hash
    (
        SELECT
            TO_HEX(MD5(STRING_AGG(DISTINCT CAST(`{COL_NAME}` AS STRING), '|' ORDER BY CAST(`{COL_NAME}` AS STRING))))
        FROM
            `{PROJECT_ID}.{DATA_SCHEMA}.{DATA_TABLE}`
    ) AS distinct_value_hash
FROM
    consol_vals;
